Instructions for execution:

In the terminal: the user can type in make to compile all the .java files in the src folder and save them in the bin folder.
The make file commands are as follows

>>make : this compiles all . java files

>>make doc : to provide documentation for the .java files

>>make clean : to clean out the folders.

>>make runPowerHash : this runs the main method in the powerHash with an empty args and the program is executed. Here on, everything is user input on the screen.

If the user wishes to uses the java commands (eg java PowerHash) from the bin folder, then the user must place the file being read into that folder or perform other similar operations in order to run properly.

Files/folders submitted:
bin
-	All .class files. User can use make of javac commands to add these
src
-	All .java files
doc
-	All the .html file along with other documentation files
-	Open. html files  to see detailed description of the methods.
Tests
-	Graphs and tables
-Makefile
-gitLog.txt
-readMe.txt
-cleaned_data.csv (please not to add the file you are testing over here, in order to test successfully) 

