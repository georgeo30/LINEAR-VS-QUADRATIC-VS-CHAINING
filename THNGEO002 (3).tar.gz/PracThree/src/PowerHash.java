/**
 *
 * @author Georgeo
 */

import java.util.*;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;

public class PowerHash {
    public static ArrayList<String>  list = new ArrayList<String>(); 
    /**
    * This is the main class in which it makes a decision on whether to run the testing analysis or just the regular program depending on user input.
    * @param args
    */
    public static void main(String[] args) {
    System.out.println("Press C to continue or Press T to do the testing analysis");    
    Scanner inTest = new Scanner(System.in);
    String query=inTest.nextLine();
    if (query.equals("C")){
        cont();
    }
    else if(query.equals("T")){
        testData();
    }
    else{
        System.out.println("Invalid input.");}
    }
    /**
    * The cont method  executes the response if the user types "C" in the main.
    * the user input the table size, the probing scheme and the file name to be used.
    * if the input table size is not a prime number. It looks for the next prime number and uses it.
    * it then creates objects and makes use of the respective probing scheme.
    */
    public static void cont(){
    int tSize;
    int searchSize;
    String type= new String();
    String file=new String();
    
    System.out.println("Enter the table size.");
    Scanner inSize = new Scanner(System.in);
    tSize=inSize.nextInt();
    int prime=otherPrimes(tSize);
    System.out.println("Using the next prime number: "+prime+" as the table size");
    System.out.println("Enter the Probing scheme of your desire (linear,quadratic,chaining).");
    Scanner inType = new Scanner(System.in);
    type=inType.nextLine();
    System.out.println("Enter the FileName. Eg \"cleaned_data.csv\" ");
    Scanner inFile = new Scanner(System.in);
    file=inFile.nextLine();
    

    if (type.equals("linear")){
        linearP l=new linearP(file,prime);
        System.out.println("Would you like to search for random keys? (yes/no)");
        Scanner searchOrNay = new Scanner(System.in);
        String ans=searchOrNay.nextLine();
        l.setProbeToZero();
        if (ans.equals("yes")){
            System.out.println("How many keys would you like to search for?");
            Scanner noOfKeys = new Scanner(System.in);
            searchSize=noOfKeys.nextInt();
            l.searchKeys(searchSize);
        }
        
    }
    else if (type.equals("quadratic")){
        quadraticP q=new quadraticP(file,prime);
        System.out.println("Would you like to search for random keys? (yes/no)");
        Scanner searchOrNay = new Scanner(System.in);
        String ans=searchOrNay.nextLine();
        q.setProbeToZero();
        if (ans.equals("yes")){
            System.out.println("How many keys would you like to search for?");
            Scanner noOfKeys = new Scanner(System.in);
            searchSize=noOfKeys.nextInt();
            q.searchKeys(searchSize);
        }
        
    }
    else if (type.equals("chaining")){
        chainingP c=new chainingP(file,prime);
        System.out.println("Would you like to search for random keys? (yes/no)");
        Scanner searchOrNay = new Scanner(System.in);
        String ans=searchOrNay.nextLine();
        c.setProbeToZero();
        if (ans.equals("yes")){
            System.out.println("How many keys would you like to search for?");
            Scanner noOfKeys = new Scanner(System.in);
            searchSize=noOfKeys.nextInt();
            c.searchKeys(searchSize);
        }
    }
    else{
        System.out.println("Invalid input.");}
    }
    /**
    * this method is used to check whether the user input table size is a prime number
    * @param n is the number to be tested whether it is a prime
    * @return a boolean answer on whether the number n is true or false.
    */
    public static boolean isPrime(int n) {
    for(int i=2;2*i<n;i++) {
        if(n%i==0)
            return false;
    }
    return true;
    }
    public static int otherPrimes(int size){
        
       while(isPrime(size)!=true){
           return otherPrimes(size+1);
          
       }
       return size;
    }
    /**
    * This is the testing method for this Assignment 
    * it takes in five table sizes and outputs the insertion and search counts to the screen for each table size.
    * A random sample of search keys is first generated and it is sent to each hashing scheme to do the testing
    * this is done in order to use the search keys.
    */ 
    public static void testData(){
        
        System.out.println("Enter the number of keys that you want to test.");
        Scanner inTestSize = new Scanner(System.in);
        int testSize=inTestSize.nextInt();
        int noOfKeys=testSize;
        System.out.println("Enter the FileName. Eg \"cleaned_data.csv\" ");
        Scanner inFile = new Scanner(System.in);
        String file=inFile.nextLine();
        System.out.println("Enter 5 table sizes(Followed by pressing enter after each one");
        int table1=inTestSize.nextInt();
        table1=otherPrimes(table1);
        int table2=inTestSize.nextInt();
        table2=otherPrimes(table2);        
        int table3=inTestSize.nextInt();
        table3=otherPrimes(table3);
        int table4=inTestSize.nextInt();
        table4=otherPrimes(table4);
        int table5=inTestSize.nextInt();
        table5=otherPrimes(table5);
        int tSizes[]={table1,table2,table3,table4,table5};
        try{
            Scanner csvFile=new Scanner(new File("cleaned_data.csv"));
            
            csvFile.nextLine();
            csvFile.useDelimiter("\n");
            while (csvFile.hasNextLine()){
                
                String[] temp=csvFile.nextLine().split(",");
                list.add(temp[0]);
           } 
            csvFile.close();
        }
        catch(Exception e){
            System.out.println(e.getMessage());
        }
        Collections.shuffle(list);
        //System.out.println(prime);
        for(int i=0;i<5;i++){
        System.out.println("----------Testing Table Size: "+tSizes[i]+"----------");
        linearP testL=new linearP(file,tSizes[i]);
        quadraticP testQ=new quadraticP(file,tSizes[i]);
        chainingP testC=new chainingP(file,tSizes[i]);
        
        testL.testSearchKeys(noOfKeys,list);
        testL.setProbeToZero();
        testQ.testSearchKeys(noOfKeys,list);
        testQ.setProbeToZero();
        testC.testSearchKeys(noOfKeys,list);
        testC.setProbeToZero();
        
        }
    }
}
