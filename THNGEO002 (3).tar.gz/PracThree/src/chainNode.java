/**
 *
 * @author Georgeo
 */
public class chainNode {
    chainNode next;
    String data;
    /**
    *constructor for chain Node class
    * sets next to null and data to the data
    * @param dataValue
    */
    public chainNode(String dataValue) {
	next = null;
	data = dataValue;
    }
    /**
    * method to get the data at the current node
    * @return the string data
    */
    public String getData() {
	return data;
    }
    /**
    * method to set the data
    * @param dataValue
    */
    public void setData(String dataValue) {
	data = dataValue;
    }
    /**
    * method to get the next Node
    * @return chainNode
    */
    public chainNode getNext() {
        return next;
    }
    /**
    * method to set the set the next node.
    * @param nextValue
    */
    public void setNext(chainNode nextValue) {
	next = nextValue;
    }
                
 
}
