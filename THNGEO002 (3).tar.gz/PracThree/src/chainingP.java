/**
 *
 * @author Georgeo
 */
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.util.*;
public class chainingP {
    public static chainNode[] llArr;
    public static int tableSize;
    public static int totalItems;
    public static ArrayList<String>  allElements = new ArrayList<String>(); 
    
    public static String fileN;
    /**
    * Constructor
    * takes in the file name and table size from the use input.
    * sets it
    * gets the total number of items in the file.
    * inserts the data into the tablle by calling the invoke method.
    * @param file
    * @param tSize
    */
    public chainingP(String file,int tSize){
        
        tableSize=tSize;
        fileN=file;
        llArr = new chainNode[tableSize];
        
        try{
            Scanner csvFile=new Scanner(new File(fileN));
            
            csvFile.nextLine();
            csvFile.useDelimiter("\n");
            while (csvFile.hasNextLine()){
                
                String[] temp=csvFile.nextLine().split(",");
                totalItems++;
           } 
            csvFile.close();
        }
        catch(Exception e){
            System.out.println(e.getMessage());
        }
 
        invoke();
        totalItems=0;
        
    }
    /**
    * method to insert all the data into the hash table
    * prints out the load factor and total insertions
    * 
    */
    public void invoke(){
        try{
            Scanner csvFile=new Scanner(new File(fileN));
            
            csvFile.nextLine();
            csvFile.useDelimiter("\n");
            
            while (csvFile.hasNextLine()){
                
                String[] temp=csvFile.nextLine().split(",");
                allElements.add(temp[0]); 
                long uniVal=hash(temp[0]);
                linearHash(uniVal,temp[0]+","+temp[1]+","+temp[3]);  
            }
            csvFile.close();
        }
        catch(Exception e){
            System.out.println(e.getMessage());
        }
        System.out.println("Inserting to hash table using chaining Sucessful");
        double lf=(double) totalItems/tableSize;
        System.out.printf("The load Factor for this data was: "+"%.2f", lf);
        System.out.println("\nThe total Number of probes during insertion is: "+getProbe());
       
    }
    /**
    * method to get n random search and search for all these keys
    * prints out the total probes to search all keys
    * prints out the average probes to search all keys
    * prints out the maximum probes to search all keys
    * @param noOfKeys 
    */
    public static void searchKeys(int noOfKeys){
        
        setProbeToZero();
        String[] newArr=new String[noOfKeys];
        Collections.shuffle(allElements);
        int max=0;
        for (int i =0;i<noOfKeys;i++){
            //System.out.println("Searching key: "+allElements.get(i));
            long uniVal=hash(allElements.get(i));
            linearSearchHash(uniVal,allElements.get(i));
            if (getMaxProbe()>max){
                max=getMaxProbe();
            }
            setMaxToZero();
     
        }
        System.out.println("Total number of probes:"+getProbe());
        double average=(double)getProbe()/noOfKeys;
        System.out.println("The average number of probes: "+average);
        System.out.println("The maximun Probe is: "+ max);
    }
    /**
    * method to return a unique value of the data key
    * @param date
    * @return a long unique value hashed from the date String
    */
    public static long hash(String date){
        long hashVal=0;
        for (int i=0;i<date.length();i++){
            long asci=(int)date.charAt(i);
            hashVal=(37*hashVal)+asci;
        }
        return hashVal*-1;
    }
    public static int totalProbes=0;
    public static int maxProbes=0;
    /**
    * method to to get the hash value of the unique value passed on by getting the mod
    * @param uniVal
    * @param data
    * @return 
    */
    public static void linearHash(long uniVal,String data){
        int hashVal=Integer.parseInt(uniVal%tableSize+"");
       llArr[hashVal]= insert(llArr[hashVal],data);
          
    }
    /**
    * method to insert the data item into the hash table using chaining
    * checks for duplicates
    * @param n
    * @param data
    */
    public static chainNode insert(chainNode n,String data){

    chainNode new_node = new chainNode(data); 

    if ( n== null) 
    { 
        n = new chainNode(data); 
        return n; 
    } 

    new_node.next = null; 

    chainNode last = n;  
    while (last.next != null) 
        
        if(last.data.equals(data)){
            System.out.println("Duplicate Error");
            System.exit(0);
        }
        else{
            last = last.next;
            totalProbes++;
        }
        
 
    last.next = new_node; 
    return n; 
    }
    /**
  * method to search for a date by invoking the linkedlist chaining
  * @param uniVal
  * @param element
  */
    public static void linearSearchHash(long uniVal,String element){
       
        int linearHashVal=Integer.parseInt(uniVal%tableSize+"");
        search(llArr[linearHashVal], element);       
    }
    /**
  * method to search the for item in chaining
  * @param n
  * @param data
  * @return 
  */
    public static void search(chainNode n,String data){
                  
        chainNode current = n;
        totalProbes--;
        while (current != null) 
        {   totalProbes++;
            maxProbes++;
            if (data.equals(current.data.split(",")[0])){break; }
                //System.out.println("found!"+current.data);}

            current = current.next; 
        } 
        
                
    }
    /**
    * method to set probe count to zero
    */
    public static void setProbeToZero(){
        totalProbes=0;
    }
    /**
    * method to return the probe count
    * @return probe count
    */
    public static int getProbe(){
        return totalProbes;
    }
    /**
    * method to set max count to zero
    */
    public static void setMaxToZero(){
        maxProbes=0;
    }
    /**
    * method to return the max count
    * @return probe count
    */
    public static int getMaxProbe(){
        return maxProbes;
    }
    
    /**
    * method to search for the same set of keys when doing testing analysis
    * receives an arrray list of the elements to be tested from the main
    * @param noOfKeys
    * @param spec
    */
    public static void testSearchKeys(int noOfKeys,ArrayList<String>  spec){
        
        setProbeToZero();
        
        int max=0;
        for (int i =0;i<noOfKeys;i++){
            //System.out.println("Searching key: "+spec.get(i));
            long uniVal=hash(spec.get(i));
            linearSearchHash(uniVal,spec.get(i));
            if (getMaxProbe()>max){
                max=getMaxProbe();
            }
            setMaxToZero();
     
        }
        System.out.println("______FOR CHAINING______");
        System.out.println("Total number of probes:"+getProbe());
        double average=(double)getProbe()/noOfKeys;
        System.out.println("The average number of probes: "+average);
        System.out.println("The maximun Probe is: "+ max);
    }
         
}
