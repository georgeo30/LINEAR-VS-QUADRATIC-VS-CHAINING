/**
 *
 * @author Georgeo
 */
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.util.*;
public class linearP {
    public static String[] linearArr;
    public static int tableSize;
    public static int totalItems;
    public static ArrayList<String>  allElements = new ArrayList<String>(); 
    
    public static String fileN;
    /**
    * Constructor
    * takes in the file name and table size from the use input.
    * sets it
    * gets the total number of items in the file.
    * inserts the data into the table by calling the invoke method.
    * if all the elements wont fit, it exits and out puts the table size is too small
    * @param file
    * @param tSize
    */
    public linearP(String file,int tSize){
        linearArr=new String[tSize];
        tableSize=tSize;
        fileN=file;
        try{
            Scanner csvFile=new Scanner(new File(fileN));
            
            csvFile.nextLine();
            csvFile.useDelimiter("\n");
            while (csvFile.hasNextLine()){
                
                String[] temp=csvFile.nextLine().split(",");
                totalItems++;
           } 
            csvFile.close();
        }
        catch(Exception e){
            System.out.println(e.getMessage());
        }
        //System.out.println(totalItems);
        if (totalItems > tableSize){
            System.out.println("Table Size too small. Please ReStart and use an appropriate table size.");
            System.exit(0);
        }
        
                invoke();
        totalItems=0;
        
    }
    /**
    * method to insert all the data into the hash table
    * prints out the load factor and total insertions
    * 
    */
    public void invoke(){
        try{
            Scanner csvFile=new Scanner(new File(fileN));
            
            csvFile.nextLine();
            csvFile.useDelimiter("\n");
            
            while (csvFile.hasNextLine()){
                
                String[] temp=csvFile.nextLine().split(",");
                allElements.add(temp[0]);
                
                long uniVal=hash(temp[0]);
                //System.out.println(uniVal);
                //System.out.println(temp[0]);
                int insertPoint=Integer.parseInt(linearHash(uniVal)+"");
                //System.out.println(insertPoint);
                linearArr[insertPoint]=temp[0]+","+temp[1]+","+temp[3];

            }
            csvFile.close();
        }
        catch(Exception e){
            System.out.println(e.getMessage());
        }
        System.out.println("Inserting to Linear Hash Table Sucessful");
        //System.out.println(totalItems+"..."+tableSize);
        double lf=(double) totalItems/tableSize;
        System.out.printf("The load Factor for this data was: "+"%.2f", lf);
        System.out.println("\nThe total Number of probes during insertion is: "+getProbe());
       
    }
    /**
    * method to get n random search and search for all these keys
    * prints out the total probes to search all keys
    * prints out the average probes to search all keys
    * prints out the maximum probes to search all keys
    * @param noOfKeys 
    */
    public static void searchKeys(int noOfKeys){
        
        setProbeToZero();
        String[] newArr=new String[noOfKeys];
        Collections.shuffle(allElements);
        int max=0;
        for (int i =0;i<noOfKeys;i++){
            //System.out.println("Searching key: "+allElements.get(i));
            long uniVal=hash(allElements.get(i));
            linearSearchHash(uniVal,allElements.get(i));
            if (getMaxProbe()>max){
                max=getMaxProbe();
            }
            setMaxToZero();
     
        }
        System.out.println("Total number of probes:"+getProbe());
        double average=(double)getProbe()/noOfKeys;
        System.out.println("The average number of probes: "+average);
        System.out.println("The maximun Probe is: "+ max);
    }
    /**
    * method to return a unique value of the data key
    * @param date
    * @return a long unique value hashed from the date String
    */
    public static long hash(String date){
        long hashVal=0;
        for (int i=0;i<date.length();i++){
            long asci=(int)date.charAt(i);
            hashVal=(37*hashVal)+asci;
        }
        return hashVal*-1;
    }
    
    public static int totalProbes=0;
    public static int maxProbes=0;
    /**
    * method to to get the hash value of the unique value passed on by getting the mod
    * checks if the hash value is taken, if it is, it gets the next hash value and repeats
    * increments by one
    * @param uniVal
    * @return 
    */
    public static long linearHash(long uniVal){
        
        int linearHashVal=Integer.parseInt(uniVal%tableSize+"");
        int j=0;
        while(linearArr[linearHashVal]!=null){
            totalProbes++;
            j++;
            linearHashVal=Integer.parseInt((uniVal+j)%tableSize+"");
        }
        return linearHashVal;
        
      
    }
   /**
    * method to search for a data item passed on from the search keys
    * checks for duplicates
    * @param uniVal
    * @param element
    */ 
   public static void linearSearchHash(long uniVal,String element){
       
        int linearHashVal=Integer.parseInt(uniVal%tableSize+"");
        
        int j=0;
        while(linearArr[linearHashVal].substring(0, 19).equals(element)==false){
            totalProbes++;
            maxProbes++;
            j++;
            linearHashVal=Integer.parseInt((uniVal+j)%tableSize+"");
        }    
            
       
            //System.out.println("Found! "+linearArr[linearHashVal]);
            
            
       
    }
    /**
    * method to set probe count to zero
    */
    public static void setProbeToZero(){
        totalProbes=0;
    }
    /**
    * method to return the probe count
    * @return probe count
    */
    public static int getProbe(){
        return totalProbes;
    }
    /**
    * method to set max count to zero
    */
    public static void setMaxToZero(){
        maxProbes=0;
    }
    /**
    * method to return the max count
    * @return probe count
    */
    public static int getMaxProbe(){
        return maxProbes;
    }
    /**
    * method to search for the same set of keys when doing testing analysis
    * receives an arrray list of the elements to be tested from the main
    * @param noOfKeys
    * @param spec
    */
    public static void testSearchKeys(int noOfKeys,ArrayList<String>  spec){
        
        setProbeToZero();
        
        int max=0;
        for (int i =0;i<noOfKeys;i++){
            //System.out.println("Searching key: "+spec.get(i));
            long uniVal=hash(spec.get(i));
            linearSearchHash(uniVal,spec.get(i));
            if (getMaxProbe()>max){
                max=getMaxProbe();
            }
            setMaxToZero();
     
        }
        System.out.println("______FOR LINEAR______");
        System.out.println("Total number of probes:"+getProbe());
        double average=(double)getProbe()/noOfKeys;
        System.out.println("The average number of probes: "+average);
        System.out.println("The maximun Probe is: "+ max);
    }
}
